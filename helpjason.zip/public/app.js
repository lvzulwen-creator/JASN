const toast = document.querySelector('#toast');
const copyButton = document.querySelector('#copy-address');
const shareButton = document.querySelector('#share-button');
let toastTimeout;

function showToast(message) {
  window.clearTimeout(toastTimeout);
  toast.textContent = message;
  toast.classList.add('is-visible');
  toastTimeout = window.setTimeout(() => {
    toast.classList.remove('is-visible');
  }, 3600);
}

async function copyText(text) {
  if (navigator.clipboard?.writeText) {
    await navigator.clipboard.writeText(text);
    return;
  }

  const temporaryInput = document.createElement('textarea');
  temporaryInput.value = text;
  temporaryInput.setAttribute('readonly', '');
  temporaryInput.style.position = 'fixed';
  temporaryInput.style.opacity = '0';
  document.body.appendChild(temporaryInput);
  temporaryInput.select();
  document.execCommand('copy');
  temporaryInput.remove();
}

copyButton?.addEventListener('click', async () => {
  const addressElement = document.querySelector(`#${copyButton.dataset.copyTarget}`);
  const address = addressElement?.textContent?.trim();
  const status = copyButton.querySelector('.copy-status');

  if (!address) return;

  try {
    await copyText(address);
    status.textContent = 'Copied';
    showToast('Bitcoin address copied. Please verify it in your wallet before sending.');
    window.setTimeout(() => {
      status.textContent = '';
    }, 3200);
  } catch {
    showToast('Unable to copy automatically. Please select the address manually.');
  }
});

shareButton?.addEventListener('click', async () => {
  const shareData = {
    title: 'Help Jason Fight His Brain Tumor',
    text: 'Help Jason access continuing medical care, rehabilitation, and everyday support.',
    url: window.location.href,
  };

  try {
    if (navigator.share) {
      await navigator.share(shareData);
      return;
    }
    await copyText(shareData.url);
    showToast('Campaign link copied — thank you for sharing Jason’s story.');
  } catch (error) {
    if (error?.name !== 'AbortError') {
      showToast('Sharing is unavailable right now.');
    }
  }
});

const revealElements = document.querySelectorAll('.reveal');
if ('IntersectionObserver' in window && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
  const observer = new IntersectionObserver((entries, currentObserver) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add('is-visible');
        currentObserver.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12 });

  revealElements.forEach((element) => observer.observe(element));
} else {
  revealElements.forEach((element) => element.classList.add('is-visible'));
}
